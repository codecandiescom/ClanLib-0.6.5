#include "TicTacToeGame.h"

// Constructor
TicTacToeGame::TicTacToeGame() {

	alive = true;
	loadGraphics();

	mousePress = CL_Mouse::sig_button_press().connect(this, &TicTacToeGame::handleMousePress);
}

// Destructor
TicTacToeGame::~TicTacToeGame() {

	// Delete the surfaces
	delete board;
	delete o;
	delete x;
	delete menu;
}

void TicTacToeGame::loadGraphics() {

	// create loads the file with the given name and stores it for us; we only
	// need a pointer to access it.
	board = new CL_Surface("board.tga");
	o = new CL_Surface("o.tga");
	x = new CL_Surface("x.tga");
	menu = new CL_Surface("menu.tga");
}

void TicTacToeGame::run() {

	while (alive && !CL_Keyboard::get_keycode(CL_KEY_ESCAPE)) {

		// Game update function
		paint();

		CL_Display::flip_display();
		CL_System::sleep(10);
		CL_System::keep_alive();
	}
}

void TicTacToeGame::paint() {

	// First we want to clear the screen to a certain R, G, B color
	// 0, 0, 0, is black (1 is the alpha paramater - we want it full)
	CL_Display::clear_display(0, 0, 0, 1);

	// Paint the board to the screen
	board->put_screen(75, 25);

	// Paint a sample move to the screen
	o->put_screen(200, 150);

	// Paint the 'restart / quit' menu below the board
	menu->put_screen(75, 400);
}

void TicTacToeGame::handleMousePress(CL_InputDevice *device, const CL_Key &key) {

	// Since a clicked happened, get the screen coordinates of the mouse
	int x = key.x, y = key.y;

	// 4 points forming a box around the 'Quit' label
	int quitX = 300, quitY = 400, quitWidth = 85, quitHeight = 20;

	// See if the x and y mouse coordinates lie inside that box
	if (x > quitX && x < quitX+quitWidth && y > quitY && y < quitY+quitHeight) {
		alive = false;
	}
}
