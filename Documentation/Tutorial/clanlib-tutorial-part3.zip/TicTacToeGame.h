// Include necessary CL header files
#include <ClanLib/core.h>
#include <ClanLib/display.h>
#include <ClanLib/application.h>

#ifndef TICTACTOEGAME_H
#define TICTACTOEGAME_H

class TicTacToeGame {

public:
	TicTacToeGame();
	~TicTacToeGame();

	void loadGraphics();	// Load the game graphics
	void paint();			// Paint the board and moves
	void run();				// Game loop
	void handleMousePress(CL_InputDevice *device, const CL_Key &key);

private:
	bool alive;
	CL_Surface *board, *o, *x, *menu;
	CL_Slot mousePress;
};

#endif