// Include necessary CL header files
#include <ClanLib/core.h>
#include <ClanLib/display.h>
#include <ClanLib/application.h>

#ifndef TICTACTOEGAME_H
#define TICTACTOEGAME_H

class TicTacToeGame {

public:
	TicTacToeGame();
	~TicTacToeGame();

	void loadGraphics();	// Load the game graphics
	void paint();			// Paint the board and moves
	void run();				// Game loop

private:
	bool alive;
	CL_Surface *board, *o, *x, *menu;

};

#endif