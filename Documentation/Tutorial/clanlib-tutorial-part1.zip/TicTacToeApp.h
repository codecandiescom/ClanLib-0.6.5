#ifndef TICTACTOEAPP_H
#define TICTACTOEAPP_H

// Include necessary CL header files
#include <ClanLib/core.h>
#include <ClanLib/display.h>
#include <ClanLib/application.h>

class TicTacToeApp : public CL_ClanApplication {

public:
	TicTacToeApp();
	~TicTacToeApp();

	char *get_title() { return "TicTacToeApp"; }

	virtual int main(int, char **);
};

#endif