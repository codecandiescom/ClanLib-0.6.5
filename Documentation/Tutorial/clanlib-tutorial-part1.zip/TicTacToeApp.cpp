#include "TicTacToeApp.h"

// Implementation (for the .cpp file)

// This application instance is required or the app will not run
TicTacToeApp applicationInstance; 

// Constructor
TicTacToeApp::TicTacToeApp() {}

// Destructor
TicTacToeApp::~TicTacToeApp() {}

int TicTacToeApp::main(int, char **) {

	// Create a console window for text-output if not available
	CL_ConsoleWindow console("TicTacToeApp Console");
	console.redirect_stdio();

	try	{
	
		CL_SetupCore::init();
		CL_SetupDisplay::init();

		// Set display mode
		CL_Display::set_videomode(500, 450, 32, false);
		
		// Program code goes here
		// Of course, it does not have to be contained in this function

		CL_SetupDisplay::deinit();
		CL_SetupCore::deinit();

	} catch (CL_Error err) {
		std::cout << "Exception caught: " << err.message.c_str() << std::endl;

		// Display console close message and wait for a key
		console.display_close_message();
	}

	return 0;
}