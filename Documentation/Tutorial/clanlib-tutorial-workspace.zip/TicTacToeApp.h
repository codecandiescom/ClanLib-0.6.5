// Include necessary CL header files
#include <ClanLib/core.h>
#include <ClanLib/display.h>
#include <ClanLib/application.h>

#include "TicTacToeGame.h"

#ifndef TICTACTOEAPP_H
#define TICTACTOEAPP_H

class TicTacToeApp : public CL_ClanApplication {

public:
	TicTacToeApp();
	~TicTacToeApp();

	// These functions must be included or the class will remain abstract

	char *get_title() { return "TicTacToeApp"; }	// Return a title string for the window
	virtual int main(int, char **);					// Game code
};

#endif