#include "TicTacToeApp.h"

// This application instance is required or the app will not run
TicTacToeApp applicationInstance; 

// Constructor
TicTacToeApp::TicTacToeApp() {}

// Destructor
TicTacToeApp::~TicTacToeApp() {}

int TicTacToeApp::main(int, char **) {

	try	{
		// CL initialization functions
		// These must be called or CL functions will not work
		// Also, SetupCore must be init()'ed first and denit()'ed last
		CL_SetupCore::init();
		CL_SetupDisplay::init();

		// Set display mode
		CL_Display::set_videomode(500, 450, 32, false);
		
		TicTacToeGame myGame;
		myGame.run();

		// CL deinitialization functions
		// These must be called because CL does not unload itself
		CL_SetupDisplay::deinit();
		CL_SetupCore::deinit();

	} catch (CL_Error err) {

	}

	return 0;
}